Attribute VB_Name = "RelaisNatation"
Option Explicit
'=====================================================================
'  OUTIL RELAIS NATATION - macros des boutons
'  Nouvelle proposition / Valider / Nouveau tournoi (x2) / Effacer
'  Lancer InstallerBoutons une fois apres l'import de ce module.
'=====================================================================

Private Const P_FIRST As Long = 4
Private Const P_LAST As Long = 203
Private Const K_PRES As Long = 2
Private Const K_FINAL As Long = 32
Private Const K_EST As Long = 36
Private Const K_SCORE As Long = 44
Private Const E_FIRST As Long = 4
Private Const E_LAST As Long = 23
Private Const T_FIRST As Long = 7
Private Const T_LAST As Long = 506
Private Const S1_FIRST As Long = 7
Private Const S1_LAST As Long = 106
Private Const S2_FIRST As Long = 7
Private Const S2_LAST As Long = 26
Private Const H_PREFILL As Long = 5001
Private Const PEN_LEG As Double = 1000#
Private Const PEN_NOSWIM As Double = 300#
Private Const MAXLEGS As Long = 12
Private Const KCAND As Long = 4

' --- nageurs presents
Private nSw As Long
Private swName() As String
Private swSexe() As Long          ' 1 = F, 2 = G, 0 = inconnu
Private swCat() As String
Private swCoul() As String
Private swT() As Double           ' (nageur, nage 0..3) en s a la distance de reference, -1 = impossible
Private swEst() As Boolean
Private swScore() As Double
Private swFix() As Long           ' groupe impose (couleur) ou 0
Private swStr() As String         ' strate pour l'equilibrage

' --- epreuves actives
Private nRel As Long
Private rNom() As String
Private rIs4N() As Boolean
Private rLegs() As Long
Private rDist() As Double
Private rComp() As Long           ' 1 libre, 2 parite, 3 au moins 1F1G, 4 filles, 5 garcons
Private rW() As Double
Private rExcl() As String
Private rStroke() As Long         ' (relais, parcours) -> nage 0..3
Private rOrd() As Long

' --- groupes
Private nGrp As Long
Private gNom() As String
Private grp() As Long
Private gTot() As Double
Private resAsg() As Long          ' (groupe, relais, parcours) -> nageur global
Private resNon() As Long

' --- regles
Private ruleObj As Long, ruleCoul As Long, ruleMix As Long, ruleCat As Long, ruleCompo As Long
Private maxRel As Long, toutMonde As Boolean, distRef As Double, effortLvl As Long
Private nageNom(0 To 3) As String
Private alertes As String

'=====================================================================
'  OUTILS
'=====================================================================
Private Function Sh(ByVal code As String, ByVal nom As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.CodeName = code Then
            Set Sh = ws
            Exit Function
        End If
    Next ws
    Set Sh = ThisWorkbook.Worksheets(nom)
End Function

Private Function Nm(ByVal nom As String) As Range
    Set Nm = ThisWorkbook.Names(nom).RefersToRange
End Function

Private Function OptIdx(ByVal regle As String, ByVal liste As String) As Long
    Dim v As Variant
    OptIdx = 1
    If TxtVal(Nm(regle).Value) = "" Then Exit Function
    v = Application.Match(Nm(regle).Value, Nm(liste), 0)
    If IsError(v) Then
        OptIdx = 1
    Else
        OptIdx = CLng(v)
    End If
End Function

Private Function NumVal(ByVal v As Variant, ByVal defaut As Double) As Double
    NumVal = defaut
    If IsError(v) Then Exit Function
    If IsEmpty(v) Then Exit Function
    If VarType(v) = vbString Then
        If Trim$(v) = "" Then Exit Function
    End If
    If IsNumeric(v) Then NumVal = CDbl(v)
End Function

Private Function TxtVal(ByVal v As Variant) As String
    If IsError(v) Then
        TxtVal = ""
    Else
        TxtVal = Trim$(CStr(v))
    End If
End Function

Private Function DerniereLigne(ByVal ws As Worksheet, ByVal col As Long) As Long
    DerniereLigne = ws.Cells(ws.Rows.Count, col).End(xlUp).Row
End Function

'=====================================================================
'  CHARGEMENT
'=====================================================================
Private Sub ChargerRegles()
    Dim i As Long
    ruleObj = OptIdx("R_Objectif", "L_Objectif")
    ruleCoul = OptIdx("R_Couleurs", "L_Couleurs")
    ruleMix = OptIdx("R_MixiteGroupes", "L_MixGroupes")
    ruleCat = OptIdx("R_CatGroupes", "L_CatGroupes")
    ruleCompo = OptIdx("R_CompoDefaut", "L_CompoDefaut")
    maxRel = CLng(NumVal(Nm("R_MaxRelais").Value, 0))
    If maxRel < 0 Then maxRel = 0
    toutMonde = (OptIdx("R_ToutLeMonde", "L_OuiNon") = 1)
    distRef = NumVal(Nm("R_DistRef").Value, 50)
    If distRef <= 0 Then distRef = 50
    effortLvl = OptIdx("R_Effort", "L_Effort")
    For i = 0 To 3
        nageNom(i) = TxtVal(Nm("L_Nages").Cells(i + 1, 1).Value)
    Next i
End Sub

Private Sub ChargerNageurs()
    Dim wp As Worksheet, wc As Worksheet
    Dim r As Long, k As Long, n As Long, v As Variant, s As String
    Set wp = Sh("shParticipants", "Participants")
    Set wc = Sh("shCalculs", "Calculs")
    Application.Calculate
    n = 0
    For r = P_FIRST To P_LAST
        If NumVal(wc.Cells(r, K_PRES).Value, 0) = 1 Then n = n + 1
    Next r
    nSw = n
    If n = 0 Then Exit Sub
    ReDim swName(1 To n): ReDim swSexe(1 To n): ReDim swCat(1 To n): ReDim swCoul(1 To n)
    ReDim swT(1 To n, 0 To 3): ReDim swEst(1 To n, 0 To 3): ReDim swScore(1 To n)
    ReDim swFix(1 To n): ReDim swStr(1 To n)
    n = 0
    For r = P_FIRST To P_LAST
        If NumVal(wc.Cells(r, K_PRES).Value, 0) = 1 Then
            n = n + 1
            swName(n) = TxtVal(wp.Cells(r, 2).Value)
            s = UCase$(TxtVal(wp.Cells(r, 3).Value))
            If s = "F" Then
                swSexe(n) = 1
            ElseIf s = "G" Or s = "M" Or s = "H" Then
                swSexe(n) = 2
            Else
                swSexe(n) = 0
            End If
            swCat(n) = TxtVal(wp.Cells(r, 4).Value)
            swCoul(n) = TxtVal(wp.Cells(r, 5).Value)
            For k = 0 To 3
                v = wc.Cells(r, K_FINAL + k).Value
                swT(n, k) = NumVal(v, -1)
                If VarType(v) = vbString Then swT(n, k) = -1
                If swT(n, k) <= 0 Then swT(n, k) = -1
                swEst(n, k) = (NumVal(wc.Cells(r, K_EST + k).Value, 0) = 1)
            Next k
            swScore(n) = NumVal(wc.Cells(r, K_SCORE).Value, 0)
        End If
    Next r
End Sub

Private Sub ChargerEpreuves()
    Dim we As Worksheet, r As Long, n As Long, t As Variant, c As Variant, k As Long, l As Long
    Dim tmp As Long, i As Long, j As Long, ok As Boolean
    Set we = Sh("shEpreuves", "�preuves")
    alertes = ""
    n = 0
    For r = E_FIRST To E_LAST
        If EpreuveValide(we, r, False) Then n = n + 1
    Next r
    nRel = n
    If n = 0 Then Exit Sub
    ReDim rNom(1 To n): ReDim rIs4N(1 To n): ReDim rLegs(1 To n): ReDim rDist(1 To n)
    ReDim rComp(1 To n): ReDim rW(1 To n): ReDim rExcl(1 To n): ReDim rStroke(1 To n, 1 To MAXLEGS)
    ReDim rOrd(1 To n)
    n = 0
    For r = E_FIRST To E_LAST
        If EpreuveValide(we, r, True) Then
            n = n + 1
            rNom(n) = TxtVal(we.Cells(r, 2).Value)
            t = Application.Match(we.Cells(r, 3).Value, Nm("L_Types"), 0)
            rLegs(n) = CLng(NumVal(we.Cells(r, 4).Value, 4))
            rDist(n) = NumVal(we.Cells(r, 5).Value, distRef)
            rIs4N(n) = (CLng(t) = 1)
            For l = 1 To rLegs(n)
                Select Case CLng(t)
                    Case 1: k = (l - 1) Mod 4
                    Case 2: k = 3
                    Case 3: k = 0
                    Case 4: k = 1
                    Case Else: k = 2
                End Select
                rStroke(n, l) = k
            Next l
            If TxtVal(we.Cells(r, 6).Value) = "" Then
                c = CVErr(2042)
            Else
                c = Application.Match(we.Cells(r, 6).Value, Nm("L_Compo"), 0)
            End If
            If IsError(c) Then
                rComp(n) = ruleCompo
            ElseIf CLng(c) <= 1 Then
                rComp(n) = ruleCompo
            Else
                rComp(n) = CLng(c) - 1
            End If
            rW(n) = NumVal(we.Cells(r, 7).Value, 1)
            If rW(n) <= 0 Then rW(n) = 1
            rExcl(n) = UCase$(TxtVal(we.Cells(r, 8).Value))
            rOrd(n) = n
        End If
    Next r
    ' ordre de resolution : poids decroissant, 4 nages d'abord
    For i = 2 To nRel
        tmp = rOrd(i)
        j = i - 1
        Do While j >= 1
            If CleRelais(rOrd(j)) >= CleRelais(tmp) Then Exit Do
            rOrd(j + 1) = rOrd(j)
            j = j - 1
        Loop
        rOrd(j + 1) = tmp
    Next i
End Sub

Private Function CleRelais(ByVal r As Long) As Double
    CleRelais = rW(r) * 1000 + IIf(rIs4N(r), 100, 0) + rLegs(r)
End Function

Private Function EpreuveValide(ByVal we As Worksheet, ByVal r As Long, ByVal noter As Boolean) As Boolean
    Dim t As Variant, nl As Double, nom As String
    EpreuveValide = False
    If TxtVal(we.Cells(r, 1).Value) = "" Then Exit Function
    t = Application.Match(we.Cells(r, 1).Value, Nm("L_OuiNon"), 0)
    If IsError(t) Then Exit Function
    If CLng(t) <> 1 Then Exit Function
    nom = TxtVal(we.Cells(r, 2).Value)
    If nom = "" Then Exit Function
    If TxtVal(we.Cells(r, 3).Value) = "" Then
        t = CVErr(2042)
    Else
        t = Application.Match(we.Cells(r, 3).Value, Nm("L_Types"), 0)
    End If
    If IsError(t) Then
        If noter Then alertes = alertes & "�preuve � " & nom & " � ignor�e : type manquant." & vbLf
        Exit Function
    End If
    nl = NumVal(we.Cells(r, 4).Value, 0)
    If nl < 1 Or nl > MAXLEGS Then
        If noter Then alertes = alertes & "�preuve � " & nom & " � ignor�e : nombre de nageurs entre 1 et 12." & vbLf
        Exit Function
    End If
    If CLng(t) = 1 And nl <> 4 Then
        If noter Then alertes = alertes & "�preuve � " & nom & " � ignor�e : un 4 nages se fait � 4 nageurs." & vbLf
        Exit Function
    End If
    If NumVal(we.Cells(r, 5).Value, 0) <= 0 Then
        If noter Then alertes = alertes & "�preuve � " & nom & " � ignor�e : distance manquante." & vbLf
        Exit Function
    End If
    EpreuveValide = True
End Function

'=====================================================================
'  GROUPES
'=====================================================================
Private Function PreparerGroupes() As Boolean
    Dim i As Long, j As Long, trouve As Boolean, maxL As Long
    PreparerGroupes = False
    For i = 1 To nSw
        swFix(i) = 0
        swStr(i) = ""
        If ruleMix = 1 Then swStr(i) = swStr(i) & CStr(swSexe(i))
        If ruleCat = 1 Then swStr(i) = swStr(i) & "|" & LCase$(swCat(i))
        If ruleCoul = 3 Then swStr(i) = swStr(i) & "|" & LCase$(swCoul(i))
    Next i
    If ruleCoul = 2 Then
        nGrp = 0
        ReDim gNom(1 To nSw)
        For i = 1 To nSw
            If swCoul(i) <> "" Then
                trouve = False
                For j = 1 To nGrp
                    If LCase$(gNom(j)) = LCase$(swCoul(i)) Then
                        swFix(i) = j
                        trouve = True
                        Exit For
                    End If
                Next j
                If Not trouve Then
                    nGrp = nGrp + 1
                    gNom(nGrp) = swCoul(i)
                    swFix(i) = nGrp
                End If
            End If
        Next i
        If nGrp = 0 Then
            MsgBox "La r�gle � couleur impos�e � est choisie, mais aucun nageur pr�sent n'a de couleur.", vbExclamation
            Exit Function
        End If
        ReDim Preserve gNom(1 To nGrp)
    Else
        nGrp = CLng(NumVal(Nm("R_NbGroupes").Value, 0))
        If nGrp <= 0 Then
            maxL = 0
            For i = 1 To nRel
                If rLegs(i) > maxL Then maxL = rLegs(i)
            Next i
            If maxL < 1 Then maxL = 4
            nGrp = nSw \ maxL
            If nGrp < 1 Then nGrp = 1
        End If
        If nGrp > nSw Then nGrp = nSw
        ReDim gNom(1 To nGrp)
        For j = 1 To nGrp
            If ruleObj = 2 Then
                gNom(j) = "�quipe " & j
            Else
                gNom(j) = "Groupe " & j
            End If
        Next j
    End If
    ReDim grp(1 To nSw)
    ReDim gTot(1 To nGrp)
    PreparerGroupes = True
End Function

Private Sub RepartitionInitiale(ByVal bruit As Double)
    Dim idx() As Long, cle() As String, vSc() As Double
    Dim i As Long, j As Long, n As Long, p As Long, tour As Long, pos As Long, gg As Long
    Dim ti As Long, tc As String, tv As Double, avant As Boolean, aFixe As Boolean
    Dim cnt() As Long, cible() As Long, somme() As Double, best As Long
    ReDim idx(1 To nSw): ReDim cle(1 To nSw): ReDim vSc(1 To nSw)
    ReDim cnt(1 To nGrp): ReDim cible(1 To nGrp): ReDim somme(1 To nGrp)
    n = 0
    aFixe = False
    For i = 1 To nSw
        If swFix(i) > 0 Then
            grp(i) = swFix(i)
            cnt(swFix(i)) = cnt(swFix(i)) + 1
            somme(swFix(i)) = somme(swFix(i)) + swScore(i)
            aFixe = True
        Else
            n = n + 1
            idx(n) = i
            If ruleObj = 2 Then cle(n) = "" Else cle(n) = swStr(i)
            vSc(n) = swScore(i) * (1 + bruit * (2 * Rnd() - 1))
        End If
    Next i
    ' tri : strate croissante puis score decroissant
    For i = 2 To n
        ti = idx(i): tc = cle(i): tv = vSc(i)
        j = i - 1
        Do While j >= 1
            If cle(j) < tc Then
                avant = True
            ElseIf cle(j) = tc And vSc(j) >= tv Then
                avant = True
            Else
                avant = False
            End If
            If avant Then Exit Do
            idx(j + 1) = idx(j): cle(j + 1) = cle(j): vSc(j + 1) = vSc(j)
            j = j - 1
        Loop
        idx(j + 1) = ti: cle(j + 1) = tc: vSc(j + 1) = tv
    Next i
    If ruleObj = 2 And Not aFixe Then
        ' meilleure equipe d'abord : on remplit l'equipe 1, puis la 2...
        For gg = 1 To nGrp
            cible(gg) = nSw \ nGrp
            If gg <= (nSw Mod nGrp) Then cible(gg) = cible(gg) + 1
        Next gg
        gg = 1
        For p = 1 To n
            Do While cnt(gg) >= cible(gg) And gg < nGrp
                gg = gg + 1
            Loop
            grp(idx(p)) = gg
            cnt(gg) = cnt(gg) + 1
        Next p
    ElseIf aFixe Then
        ' groupes deja amorces par les couleurs : le plus petit groupe choisit
        For p = 1 To n
            best = 1
            For gg = 2 To nGrp
                If cnt(gg) < cnt(best) Or (cnt(gg) = cnt(best) And somme(gg) < somme(best)) Then best = gg
            Next gg
            grp(idx(p)) = best
            cnt(best) = cnt(best) + 1
            somme(best) = somme(best) + swScore(idx(p))
        Next p
    Else
        ' serpentin : 1-2-3-3-2-1-1-2-3...
        For p = 0 To n - 1
            tour = p \ nGrp
            pos = p Mod nGrp
            If tour Mod 2 = 0 Then
                gg = pos + 1
            Else
                gg = nGrp - pos
            End If
            grp(idx(p + 1)) = gg
        Next p
    End If
End Sub

Private Sub CalculerTousGroupes(ByVal stocker As Boolean)
    Dim gg As Long
    If stocker Then
        ReDim resAsg(1 To nGrp, 1 To nRel, 1 To MAXLEGS)
        ReDim resNon(1 To nGrp)
    End If
    For gg = 1 To nGrp
        gTot(gg) = EvalGroupe(gg, stocker)
    Next gg
End Sub

Private Function Objectif() As Double
    Dim gg As Long, mx As Double, mn As Double, s As Double, w As Double, o As Double
    mx = -1E+30: mn = 1E+30: s = 0
    For gg = 1 To nGrp
        s = s + gTot(gg)
        If gTot(gg) > mx Then mx = gTot(gg)
        If gTot(gg) < mn Then mn = gTot(gg)
    Next gg
    If ruleObj = 2 Then
        w = 1: o = 0
        For gg = nGrp To 1 Step -1
            o = o + gTot(gg) * w
            w = w * 10
        Next gg
        Objectif = o
    Else
        Objectif = (mx - mn) + 0.001 * s
    End If
End Function

Private Sub RechercheLocale()
    Dim pa() As Long, pb() As Long, np As Long, i As Long, j As Long, t As Long, u As Long, tmp As Long
    Dim passes As Long, maxEval As Long, nEval As Long, ameliore As Boolean, pass As Long
    Dim ga As Long, gb As Long, oldA As Double, oldB As Double, objOld As Double, objNew As Double
    If nGrp < 2 Or nRel = 0 Then Exit Sub
    Select Case effortLvl
        Case 1
            passes = 2: maxEval = 300
        Case 2
            passes = 4: maxEval = 1500
        Case Else
            passes = 12: maxEval = 6000
    End Select
    ReDim pa(1 To nSw * nSw \ 2 + 1): ReDim pb(1 To nSw * nSw \ 2 + 1)
    np = 0
    For i = 1 To nSw - 1
        For j = i + 1 To nSw
            If swFix(i) = 0 And swFix(j) = 0 Then
                If ruleObj = 2 Or swStr(i) = swStr(j) Then
                    np = np + 1: pa(np) = i: pb(np) = j
                End If
            End If
        Next j
    Next i
    If np = 0 Then Exit Sub
    objOld = Objectif()
    nEval = 0
    For pass = 1 To passes
        ameliore = False
        For t = np To 2 Step -1
            u = Int(Rnd() * t) + 1
            tmp = pa(t): pa(t) = pa(u): pa(u) = tmp
            tmp = pb(t): pb(t) = pb(u): pb(u) = tmp
        Next t
        For t = 1 To np
            i = pa(t): j = pb(t)
            If grp(i) <> grp(j) Then
                ga = grp(i): gb = grp(j)
                grp(i) = gb: grp(j) = ga
                oldA = gTot(ga): oldB = gTot(gb)
                gTot(ga) = EvalGroupe(ga, False)
                gTot(gb) = EvalGroupe(gb, False)
                nEval = nEval + 2
                objNew = Objectif()
                If objNew < objOld - 0.0001 Then
                    objOld = objNew
                    ameliore = True
                Else
                    grp(i) = ga: grp(j) = gb
                    gTot(ga) = oldA: gTot(gb) = oldB
                End If
                If nEval Mod 100 = 0 Then
                    Application.StatusBar = "Recherche des meilleurs groupes� " & nEval & " / " & maxEval
                    DoEvents
                End If
                If nEval >= maxEval Then Exit For
            End If
        Next t
        If Not ameliore Or nEval >= maxEval Then Exit For
    Next pass
End Sub

'=====================================================================
'  RELAIS D'UN GROUPE
'=====================================================================
Private Function TempsNage(ByVal s As Long, ByVal r As Long, ByVal l As Long) As Double
    Dim t As Double
    t = swT(s, rStroke(r, l))
    If t <= 0 Then
        TempsNage = 1E+9
    Else
        TempsNage = t * rDist(r) / distRef
    End If
End Function

Private Sub BornesCompo(ByVal c As Long, ByVal n As Long, minF As Long, maxF As Long, minG As Long, maxG As Long, maxU As Long)
    minF = 0: maxF = n: minG = 0: maxG = n: maxU = n
    Select Case c
        Case 2
            minF = n \ 2: maxF = n - n \ 2: minG = n \ 2: maxG = n - n \ 2: maxU = n Mod 2
        Case 3
            If n >= 2 Then
                minF = 1: minG = 1
            End If
        Case 4
            maxG = 0: maxU = 0
        Case 5
            maxF = 0: maxU = 0
    End Select
End Sub

Private Function EvalGroupe(ByVal gg As Long, ByVal stocker As Boolean) As Double
    Dim mem() As Long, k As Long, i As Long, r As Long, l As Long, p As Long, pass As Long
    Dim uc() As Long, asg() As Long, cout As Double, nonN As Long
    k = 0
    ReDim mem(1 To nSw)
    For i = 1 To nSw
        If grp(i) = gg Then
            k = k + 1
            mem(k) = i
        End If
    Next i
    ReDim asg(1 To nRel, 1 To MAXLEGS)
    ReDim uc(0 To k)
    If k > 0 Then
        For p = 1 To nRel
            ResoudreRelais rOrd(p), mem, k, uc, asg
        Next p
        For pass = 1 To 1
            For p = 1 To nRel
                r = rOrd(p)
                For l = 1 To rLegs(r)
                    If asg(r, l) > 0 Then
                        uc(asg(r, l)) = uc(asg(r, l)) - 1
                        asg(r, l) = 0
                    End If
                Next l
                ResoudreRelais r, mem, k, uc, asg
            Next p
        Next pass
        nonN = 0
        If toutMonde Then nonN = CompleterToutLeMonde(mem, k, uc, asg)
    End If
    cout = 0
    For r = 1 To nRel
        For l = 1 To rLegs(r)
            If asg(r, l) > 0 Then
                cout = cout + rW(r) * TempsNage(mem(asg(r, l)), r, l)
            Else
                cout = cout + rW(r) * PEN_LEG
            End If
        Next l
    Next r
    cout = cout + PEN_NOSWIM * nonN
    If stocker Then
        For r = 1 To nRel
            For l = 1 To rLegs(r)
                If asg(r, l) > 0 Then
                    resAsg(gg, r, l) = mem(asg(r, l))
                Else
                    resAsg(gg, r, l) = 0
                End If
            Next l
        Next r
        resNon(gg) = nonN
    End If
    EvalGroupe = cout
End Function

Private Sub ResoudreRelais(ByVal r As Long, mem() As Long, ByVal k As Long, uc() As Long, asg() As Long)
    Dim ok() As Boolean, i As Long, r2 As Long, l As Long
    Dim minF As Long, maxF As Long, minG As Long, maxG As Long, maxU As Long
    If k = 0 Then Exit Sub
    ReDim ok(1 To k)
    For i = 1 To k
        ok(i) = (maxRel = 0 Or uc(i) < maxRel)
    Next i
    For l = 1 To rLegs(r)
        If asg(r, l) > 0 Then ok(asg(r, l)) = False
    Next l
    If rExcl(r) <> "" Then
        For r2 = 1 To nRel
            If r2 <> r And rExcl(r2) = rExcl(r) Then
                For l = 1 To rLegs(r2)
                    If asg(r2, l) > 0 Then ok(asg(r2, l)) = False
                Next l
            End If
        Next r2
    End If
    BornesCompo rComp(r), rLegs(r), minF, maxF, minG, maxG, maxU
    If rIs4N(r) Then
        Resoudre4N r, mem, k, ok, uc, asg, minF, maxF, minG, maxG, maxU
    Else
        ResoudreUneNage r, mem, k, ok, uc, asg, minF, maxF, minG, maxG, maxU
    End If
End Sub

' relais d'une seule nage : choix exact des plus rapides compatibles avec la composition
Private Sub ResoudreUneNage(ByVal r As Long, mem() As Long, ByVal k As Long, ok() As Boolean, uc() As Long, asg() As Long, _
                            ByVal minF As Long, ByVal maxF As Long, ByVal minG As Long, ByVal maxG As Long, ByVal maxU As Long)
    Dim pool() As Long, cnt(0 To 2) As Long, st As Long, i As Long, j As Long, sx As Long, tmp As Long
    Dim nL As Long, nF As Long, nG As Long, nU As Long, bF As Long, bG As Long, bU As Long
    Dim s As Double, best As Double, ch() As Long, nc As Long, ordre() As Long
    nL = rLegs(r)
    st = rStroke(r, 1)
    ReDim pool(0 To 2, 1 To k)
    For i = 1 To k
        If ok(i) And swT(mem(i), st) > 0 Then
            sx = swSexe(mem(i))
            cnt(sx) = cnt(sx) + 1
            pool(sx, cnt(sx)) = i
        End If
    Next i
    For sx = 0 To 2
        For i = 2 To cnt(sx)
            tmp = pool(sx, i)
            j = i - 1
            Do While j >= 1
                If swT(mem(pool(sx, j)), st) <= swT(mem(tmp), st) Then Exit Do
                pool(sx, j + 1) = pool(sx, j)
                j = j - 1
            Loop
            pool(sx, j + 1) = tmp
        Next i
    Next sx
    best = 1E+30: bF = -1
    For nF = minF To maxF
        For nG = minG To maxG
            nU = nL - nF - nG
            If nU >= 0 And nU <= maxU And nF <= cnt(1) And nG <= cnt(2) And nU <= cnt(0) Then
                s = 0
                For i = 1 To nF: s = s + swT(mem(pool(1, i)), st): Next i
                For i = 1 To nG: s = s + swT(mem(pool(2, i)), st): Next i
                For i = 1 To nU: s = s + swT(mem(pool(0, i)), st): Next i
                If s < best Then
                    best = s: bF = nF: bG = nG: bU = nU
                End If
            End If
        Next nG
    Next nF
    If bF < 0 Then Exit Sub
    ReDim ch(1 To nL)
    nc = 0
    For i = 1 To bF: nc = nc + 1: ch(nc) = pool(1, i): Next i
    For i = 1 To bG: nc = nc + 1: ch(nc) = pool(2, i): Next i
    For i = 1 To bU: nc = nc + 1: ch(nc) = pool(0, i): Next i
    For i = 2 To nc
        tmp = ch(i)
        j = i - 1
        Do While j >= 1
            If swT(mem(ch(j)), st) <= swT(mem(tmp), st) Then Exit Do
            ch(j + 1) = ch(j)
            j = j - 1
        Loop
        ch(j + 1) = tmp
    Next i
    ' ordre : 2e plus rapide au depart, le plus rapide en dernier
    ReDim ordre(1 To nL)
    If nL = 1 Then
        ordre(1) = ch(1)
    Else
        ordre(nL) = ch(1)
        ordre(1) = ch(2)
        For i = 3 To nL
            ordre(i - 1) = ch(i)
        Next i
    End If
    For i = 1 To nL
        asg(r, i) = ordre(i)
        uc(ordre(i)) = uc(ordre(i)) + 1
    Next i
End Sub

' relais 4 nages : recherche exhaustive parmi les meilleurs candidats de chaque nage
Private Sub Resoudre4N(ByVal r As Long, mem() As Long, ByVal k As Long, ok() As Boolean, uc() As Long, asg() As Long, _
                       ByVal minF As Long, ByVal maxF As Long, ByVal minG As Long, ByVal maxG As Long, ByVal maxU As Long)
    Dim cand() As Long, nc(0 To 3) As Long, st As Long, sx As Long, i As Long, j As Long, tmp As Long
    Dim lst() As Long, nl As Long, pris As Long, libre As Boolean
    Dim a As Long, b As Long, c As Long, d As Long, ia As Long, ib As Long, ic As Long, id As Long
    Dim ta As Double, tb As Double, tc As Double, td As Double, best As Double
    Dim ba As Long, bb As Long, bc As Long, bd As Long
    libre = (minF = 0 And minG = 0 And maxF >= 4 And maxG >= 4 And maxU >= 4)
    ReDim cand(0 To 3, 1 To 3 * KCAND)
    ReDim lst(1 To k)
    For st = 0 To 3
        For sx = 0 To 2
            If libre And sx > 0 Then Exit For
            nl = 0
            For i = 1 To k
                If ok(i) And swT(mem(i), st) > 0 Then
                    If libre Or swSexe(mem(i)) = sx Then
                        nl = nl + 1
                        lst(nl) = i
                    End If
                End If
            Next i
            For i = 2 To nl
                tmp = lst(i)
                j = i - 1
                Do While j >= 1
                    If swT(mem(lst(j)), st) <= swT(mem(tmp), st) Then Exit Do
                    lst(j + 1) = lst(j)
                    j = j - 1
                Loop
                lst(j + 1) = tmp
            Next i
            pris = nl
            If pris > KCAND Then pris = KCAND
            For i = 1 To pris
                nc(st) = nc(st) + 1
                cand(st, nc(st)) = lst(i)
            Next i
        Next sx
    Next st
    best = 1E+30: ba = 0
    For a = 1 To nc(0)
        ia = cand(0, a): ta = swT(mem(ia), 0)
        If ta < best Then
            For b = 1 To nc(1)
                ib = cand(1, b)
                If ib <> ia Then
                    tb = ta + swT(mem(ib), 1)
                    If tb < best Then
                        For c = 1 To nc(2)
                            ic = cand(2, c)
                            If ic <> ia And ic <> ib Then
                                tc = tb + swT(mem(ic), 2)
                                If tc < best Then
                                    For d = 1 To nc(3)
                                        id = cand(3, d)
                                        If id <> ia And id <> ib And id <> ic Then
                                            td = tc + swT(mem(id), 3)
                                            If td < best Then
                                                If CompoOK4(mem, ia, ib, ic, id, minF, maxF, minG, maxG, maxU) Then
                                                    best = td: ba = ia: bb = ib: bc = ic: bd = id
                                                End If
                                            End If
                                        End If
                                    Next d
                                End If
                            End If
                        Next c
                    End If
                End If
            Next b
        End If
    Next a
    If ba = 0 Then Exit Sub
    asg(r, 1) = ba: asg(r, 2) = bb: asg(r, 3) = bc: asg(r, 4) = bd
    uc(ba) = uc(ba) + 1: uc(bb) = uc(bb) + 1: uc(bc) = uc(bc) + 1: uc(bd) = uc(bd) + 1
End Sub

Private Function CompoOK4(mem() As Long, ByVal a As Long, ByVal b As Long, ByVal c As Long, ByVal d As Long, _
                          ByVal minF As Long, ByVal maxF As Long, ByVal minG As Long, ByVal maxG As Long, ByVal maxU As Long) As Boolean
    Dim n(0 To 2) As Long
    n(swSexe(mem(a))) = n(swSexe(mem(a))) + 1
    n(swSexe(mem(b))) = n(swSexe(mem(b))) + 1
    n(swSexe(mem(c))) = n(swSexe(mem(c))) + 1
    n(swSexe(mem(d))) = n(swSexe(mem(d))) + 1
    CompoOK4 = (n(1) >= minF And n(1) <= maxF And n(2) >= minG And n(2) <= maxG And n(0) <= maxU)
End Function

Private Function CompoApresEchange(ByVal r As Long, mem() As Long, asg() As Long, ByVal leg As Long, ByVal nouveau As Long) As Boolean
    Dim n(0 To 2) As Long, l As Long, m As Long
    Dim minF As Long, maxF As Long, minG As Long, maxG As Long, maxU As Long
    For l = 1 To rLegs(r)
        If l = leg Then
            m = nouveau
        Else
            m = asg(r, l)
        End If
        If m > 0 Then n(swSexe(mem(m))) = n(swSexe(mem(m))) + 1
    Next l
    BornesCompo rComp(r), rLegs(r), minF, maxF, minG, maxG, maxU
    CompoApresEchange = (n(1) <= maxF And n(2) <= maxG And n(0) <= maxU)
    If CompoApresEchange Then
        ' si le relais est complet, les minimums doivent aussi etre respectes
        If n(0) + n(1) + n(2) = rLegs(r) Then CompoApresEchange = (n(1) >= minF And n(2) >= minG)
    End If
End Function

' fait nager ceux qui n'ont aucun relais, en remplacant quelqu'un qui en a deja plusieurs
Private Function CompleterToutLeMonde(mem() As Long, ByVal k As Long, uc() As Long, asg() As Long) As Long
    Dim essaye() As Boolean, i As Long, cible As Long, r As Long, l As Long, cur As Long, l2 As Long
    Dim d As Double, bestD As Double, br As Long, bl As Long, nonN As Long, dejaDedans As Boolean
    ReDim essaye(1 To k)
    nonN = 0
    Do
        cible = 0
        For i = 1 To k
            If uc(i) = 0 And Not essaye(i) Then
                cible = i
                Exit For
            End If
        Next i
        If cible = 0 Then Exit Do
        essaye(cible) = True
        bestD = 1E+30: br = 0: bl = 0
        For r = 1 To nRel
            dejaDedans = False
            For l2 = 1 To rLegs(r)
                If asg(r, l2) = cible Then dejaDedans = True
            Next l2
            If Not dejaDedans Then
                For l = 1 To rLegs(r)
                    If swT(mem(cible), rStroke(r, l)) > 0 Then
                        cur = asg(r, l)
                        If cur = 0 Then
                            If CompoApresEchange(r, mem, asg, l, cible) Then
                                d = rW(r) * (TempsNage(mem(cible), r, l) - PEN_LEG)
                                If d < bestD Then bestD = d: br = r: bl = l
                            End If
                        ElseIf uc(cur) >= 2 Then
                            If CompoApresEchange(r, mem, asg, l, cible) Then
                                d = rW(r) * (TempsNage(mem(cible), r, l) - TempsNage(mem(cur), r, l))
                                If d < bestD Then bestD = d: br = r: bl = l
                            End If
                        End If
                    End If
                Next l
            End If
        Next r
        If br > 0 Then
            cur = asg(br, bl)
            If cur > 0 Then uc(cur) = uc(cur) - 1
            asg(br, bl) = cible
            uc(cible) = uc(cible) + 1
        Else
            nonN = nonN + 1
        End If
    Loop
    CompleterToutLeMonde = nonN
End Function

'=====================================================================
'  SIGNATURE (pour ne pas reproposer deux fois les memes groupes)
'=====================================================================
Private Sub TrierTexte(arr() As String, ByVal n As Long)
    Dim i As Long, j As Long, tmp As String
    For i = 2 To n
        tmp = arr(i)
        j = i - 1
        Do While j >= 1
            If arr(j) <= tmp Then Exit Do
            arr(j + 1) = arr(j)
            j = j - 1
        Loop
        arr(j + 1) = tmp
    Next i
End Sub

Private Function Signature() As String
    Dim gs() As String, noms() As String, gg As Long, i As Long, n As Long, s As String
    ReDim gs(1 To nGrp)
    ReDim noms(1 To nSw)
    For gg = 1 To nGrp
        n = 0
        For i = 1 To nSw
            If grp(i) = gg Then
                n = n + 1
                noms(n) = LCase$(swName(i))
            End If
        Next i
        TrierTexte noms, n
        s = ""
        For i = 1 To n
            s = s & noms(i) & ","
        Next i
        gs(gg) = s
    Next gg
    TrierTexte gs, nGrp
    s = ""
    For gg = 1 To nGrp
        s = s & gs(gg) & "|"
    Next gg
    Signature = s
End Function

Private Function SignatureExiste(ByVal sig As String) As Boolean
    Dim wd As Worksheet, r As Long, lastR As Long
    Set wd = Sh("shDonnees", "Donn�es")
    lastR = DerniereLigne(wd, 12)
    SignatureExiste = False
    For r = 2 To lastR
        If CStr(wd.Cells(r, 13).Value) = sig Then
            SignatureExiste = True
            Exit Function
        End If
    Next r
End Function

Private Function DernierePropID() As Long
    Dim wd As Worksheet, r As Long, lastR As Long, m As Double
    Set wd = Sh("shDonnees", "Donn�es")
    lastR = DerniereLigne(wd, 12)
    m = 0
    For r = 2 To lastR
        If NumVal(wd.Cells(r, 12).Value, 0) > m Then m = NumVal(wd.Cells(r, 12).Value, 0)
    Next r
    DernierePropID = CLng(m)
End Function

Private Sub VerifierFaisabilite()
    Dim gg As Long, i As Long, r As Long, k As Long, besoin As Long, kMin As Long, kMax As Long
    Dim cnt() As Long, grand As Long
    ReDim cnt(1 To nGrp)
    If ruleCoul = 2 Then
        For i = 1 To nSw
            If swFix(i) > 0 Then cnt(swFix(i)) = cnt(swFix(i)) + 1
        Next i
        kMin = 1E+9: kMax = 0
        For gg = 1 To nGrp
            If cnt(gg) < kMin Then kMin = cnt(gg)
            If cnt(gg) > kMax Then kMax = cnt(gg)
        Next gg
    Else
        kMin = nSw \ nGrp
        kMax = kMin
        If nSw Mod nGrp > 0 Then kMax = kMin + 1
    End If
    besoin = 0: grand = 0
    For r = 1 To nRel
        besoin = besoin + rLegs(r)
        If rLegs(r) > kMin Then
            alertes = alertes & "� " & rNom(r) & " � demande " & rLegs(r) & " nageurs diff�rents, mais un groupe n'en a que " & kMin & "." & vbLf
        End If
    Next r
    If maxRel > 0 And besoin > kMin * maxRel Then
        alertes = alertes & "Il y a " & besoin & " parcours � nager par groupe, mais avec " & kMin & " nageurs et " & maxRel & _
                  " relais maximum chacun, un groupe ne peut en couvrir que " & kMin * maxRel & "." & vbLf
    End If
    If toutMonde And besoin < kMax Then
        alertes = alertes & "R�gle � tout le monde nage � impossible : " & besoin & " parcours pour des groupes jusqu'� " & kMax & " nageurs." & vbLf
    End If
End Sub

'=====================================================================
'  BOUTON : NOUVELLE PROPOSITION
'=====================================================================
Public Sub NouvelleProposition()
    Dim numProp As Long, essai As Long, sig As String, bruit As Double, dup As Boolean
    On Error GoTo Erreur
    Application.ScreenUpdating = False
    Application.Cursor = xlWait
    Randomize
    ChargerRegles
    ChargerNageurs
    If nSw = 0 Then
        MsgBox "Aucun nageur pr�sent (onglet Participants, colonne Pr�sent = Oui).", vbExclamation
        GoTo Fin
    End If
    ChargerEpreuves
    If nRel = 0 Then
        MsgBox "Aucune �preuve active valide (onglet �preuves)." & vbLf & alertes, vbExclamation
        GoTo Fin
    End If
    If Not PreparerGroupes() Then GoTo Fin
    VerifierFaisabilite
    numProp = DernierePropID() + 1
    dup = True
    For essai = 1 To 8
        If numProp = 1 And essai = 1 Then
            bruit = 0
        Else
            bruit = 0.06 + 0.04 * essai
        End If
        RepartitionInitiale bruit
        CalculerTousGroupes False
        RechercheLocale
        sig = Signature()
        If Not SignatureExiste(sig) Then
            dup = False
            Exit For
        End If
    Next essai
    If dup Then alertes = alertes & "Pas trouv� de groupes diff�rents des propositions pr�c�dentes : celle-ci reprend des groupes d�j� propos�s." & vbLf
    CalculerTousGroupes True
    EcrireProposition numProp, sig
    Nm("A_NumProp").Value = numProp
Fin:
    Application.StatusBar = False
    Application.Cursor = xlDefault
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    MsgBox "Erreur pendant le calcul : " & Err.Description, vbCritical
    Resume Fin
End Sub

Private Sub EcrireProposition(ByVal numProp As Long, ByVal sig As String)
    Dim wp As Worksheet, wd As Worksheet, ws As Worksheet
    Dim row As Long, dRow As Long, gg As Long, r As Long, l As Long, s As Long, i As Long
    Dim brut() As Double, incomplet() As Long, nF As Long, nGa As Long, nb As Long, membres As String
    Dim mx As Double, mn As Double, ecart As Double, totR As Double, legsVides As Long, t As Double
    Dim nbRel() As Long, sansRelais As String, txt As String
    Set wp = Sh("shPropositions", "Propositions")
    Set wd = Sh("shDonnees", "Donn�es")
    ' totaux bruts (temps reels estimes, sans poids)
    ReDim brut(1 To nGrp): ReDim incomplet(1 To nGrp)
    For gg = 1 To nGrp
        For r = 1 To nRel
            For l = 1 To rLegs(r)
                s = resAsg(gg, r, l)
                If s > 0 Then
                    brut(gg) = brut(gg) + TempsNage(s, r, l)
                Else
                    incomplet(gg) = incomplet(gg) + 1
                End If
            Next l
        Next r
    Next gg
    mx = -1E+30: mn = 1E+30
    For gg = 1 To nGrp
        If brut(gg) > mx Then mx = brut(gg)
        If brut(gg) < mn Then mn = brut(gg)
    Next gg
    ecart = mx - mn
    ' --- donnees techniques
    dRow = DerniereLigne(wd, 1) + 1
    If dRow < 2 Then dRow = 2
    For gg = 1 To nGrp
        For s = 1 To nSw
            If grp(s) = gg Then
                wd.Cells(dRow, 1).Value = numProp
                wd.Cells(dRow, 2).Value = gNom(gg)
                wd.Cells(dRow, 3).Value = "(membre)"
                wd.Cells(dRow, 6).Value = swName(s)
                wd.Cells(dRow, 7).Value = SexeTxt(s)
                dRow = dRow + 1
            End If
        Next s
        For r = 1 To nRel
            For l = 1 To rLegs(r)
                s = resAsg(gg, r, l)
                wd.Cells(dRow, 1).Value = numProp
                wd.Cells(dRow, 2).Value = gNom(gg)
                wd.Cells(dRow, 3).Value = rNom(r)
                wd.Cells(dRow, 4).Value = l
                wd.Cells(dRow, 5).Value = nageNom(rStroke(r, l))
                wd.Cells(dRow, 8).Value = rDist(r)
                If s > 0 Then
                    wd.Cells(dRow, 6).Value = swName(s)
                    wd.Cells(dRow, 7).Value = SexeTxt(s)
                    wd.Cells(dRow, 9).Value = Round(TempsNage(s, r, l), 2)
                    If swEst(s, rStroke(r, l)) Then wd.Cells(dRow, 10).Value = "~"
                Else
                    wd.Cells(dRow, 6).Value = "(personne)"
                End If
                dRow = dRow + 1
            Next l
        Next r
    Next gg
    i = DerniereLigne(wd, 12) + 1
    If i < 2 Then i = 2
    wd.Cells(i, 12).Value = numProp
    wd.Cells(i, 13).Value = sig
    wd.Cells(i, 14).Value = Round(ecart, 2)
    wd.Cells(i, 15).Value = Now
    wd.Cells(i, 15).NumberFormat = "dd/mm/yyyy hh:mm"

    ' --- affichage
    row = DerniereLigne(wp, 1)
    If DerniereLigne(wp, 4) > row Then row = DerniereLigne(wp, 4)
    row = row + 2
    If row < 4 Then row = 4
    With wp.Range(wp.Cells(row, 1), wp.Cells(row, 6))
        .Interior.Color = RGB(31, 78, 121)
        .Font.Color = RGB(255, 255, 255)
        .Font.Bold = True
    End With
    wp.Cells(row, 1).Value = "PROPOSITION n� " & numProp
    wp.Cells(row, 1).Font.Size = 13
    wp.Cells(row, 3).Value = "Cr��e le " & Format(Now, "dd/mm/yyyy hh:nn")
    If ruleObj = 2 Then
        wp.Cells(row, 5).Value = "Objectif : meilleure �quipe d'abord"
    Else
        wp.Cells(row, 5).Value = "�cart entre groupes : " & Format(ecart, "0.00") & " s"
    End If
    row = row + 1
    If alertes <> "" Then
        wp.Cells(row, 1).Value = "Attention : " & Replace(alertes, vbLf, "  ")
        wp.Cells(row, 1).Font.Color = RGB(192, 0, 0)
        row = row + 1
    End If
    ReDim nbRel(1 To nSw)
    For gg = 1 To nGrp
        nF = 0: nGa = 0: nb = 0: membres = ""
        For s = 1 To nSw
            If grp(s) = gg Then
                nb = nb + 1
                If swSexe(s) = 1 Then nF = nF + 1
                If swSexe(s) = 2 Then nGa = nGa + 1
                membres = membres & swName(s) & ", "
            End If
        Next s
        If Len(membres) > 2 Then membres = Left$(membres, Len(membres) - 2)
        row = row + 1
        With wp.Range(wp.Cells(row, 1), wp.Cells(row, 6))
            .Interior.Color = RGB(221, 235, 247)
            .Font.Bold = True
        End With
        wp.Cells(row, 1).Value = gNom(gg) & " � " & nb & " nageurs (" & nF & " F / " & nGa & " G)"
        wp.Cells(row, 5).Value = Round(brut(gg), 2)
        wp.Cells(row, 5).NumberFormat = "0.00"
        wp.Cells(row, 6).Value = "total estim�, toutes �preuves (s)"
        row = row + 1
        wp.Cells(row, 1).Value = "Membres : " & membres
        wp.Cells(row, 1).Font.Italic = True
        row = row + 1
        wp.Cells(row, 1).Value = "�preuve"
        wp.Cells(row, 2).Value = "Parcours"
        wp.Cells(row, 3).Value = "Nage"
        wp.Cells(row, 4).Value = "Nageur"
        wp.Cells(row, 5).Value = "Temps estim� (s)"
        wp.Cells(row, 6).Value = "Remarque"
        wp.Range(wp.Cells(row, 1), wp.Cells(row, 6)).Font.Bold = True
        wp.Range(wp.Cells(row, 1), wp.Cells(row, 6)).Borders(xlEdgeBottom).LineStyle = xlContinuous
        For r = 1 To nRel
            totR = 0: legsVides = 0
            For l = 1 To rLegs(r)
                row = row + 1
                s = resAsg(gg, r, l)
                If l = 1 Then
                    wp.Cells(row, 1).Value = rNom(r)
                    wp.Cells(row, 1).Font.Bold = True
                End If
                wp.Cells(row, 2).Value = l
                wp.Cells(row, 3).Value = nageNom(rStroke(r, l))
                If s > 0 Then
                    t = TempsNage(s, r, l)
                    totR = totR + t
                    nbRel(s) = nbRel(s) + 1
                    wp.Cells(row, 4).Value = swName(s) & " (" & SexeTxt(s) & ")"
                    wp.Cells(row, 5).Value = Round(t, 2)
                    wp.Cells(row, 5).NumberFormat = "0.00"
                    If swEst(s, rStroke(r, l)) Then
                        wp.Cells(row, 6).Value = "~ temps estim�"
                        wp.Cells(row, 5).Font.Italic = True
                    End If
                Else
                    legsVides = legsVides + 1
                    wp.Cells(row, 4).Value = "(personne de disponible)"
                    wp.Cells(row, 4).Font.Color = RGB(192, 0, 0)
                End If
            Next l
            row = row + 1
            wp.Cells(row, 4).Value = "Total " & rNom(r)
            wp.Cells(row, 4).Font.Bold = True
            wp.Cells(row, 5).Value = Round(totR, 2)
            wp.Cells(row, 5).NumberFormat = "0.00"
            wp.Cells(row, 5).Font.Bold = True
            If legsVides > 0 Then
                wp.Cells(row, 6).Value = "Relais incomplet (" & legsVides & " parcours) : composition ou max de relais trop stricts ?"
                wp.Cells(row, 6).Font.Color = RGB(192, 0, 0)
            End If
        Next r
        sansRelais = ""
        For s = 1 To nSw
            If grp(s) = gg And nbRel(s) = 0 Then sansRelais = sansRelais & swName(s) & ", "
        Next s
        If sansRelais <> "" Then
            row = row + 1
            sansRelais = Left$(sansRelais, Len(sansRelais) - 2)
            If toutMonde Then
                txt = "Attention, sans relais malgr� la r�gle : "
            Else
                txt = "Ne nage aucun relais : "
            End If
            wp.Cells(row, 1).Value = txt & sansRelais
            wp.Cells(row, 1).Font.Color = RGB(192, 0, 0)
        End If
        row = row + 1
    Next gg
    wp.Activate
    wp.Cells(DerniereLigne(wp, 1), 1).Select
    Application.Goto wp.Cells(row - 1, 1), False
End Sub

Private Function SexeTxt(ByVal s As Long) As String
    Select Case swSexe(s)
        Case 1: SexeTxt = "F"
        Case 2: SexeTxt = "G"
        Case Else: SexeTxt = "?"
    End Select
End Function

'=====================================================================
'  BOUTON : VALIDER LA PROPOSITION
'=====================================================================
Public Sub ValiderProposition()
    Dim wd As Worksheet, wt As Worksheet, num As Long, lastR As Long, r As Long, tr As Long
    Dim s1 As Long, s2 As Long, i As Long, trouve As Boolean, cle As String
    Set wd = Sh("shDonnees", "Donn�es")
    Set wt = Sh("shTournoi", "Tournoi")
    num = CLng(NumVal(Nm("A_NumProp").Value, 0))
    If num = 0 Then num = DernierePropID()
    If num = 0 Then
        MsgBox "Aucune proposition � valider : cliquez d'abord sur � Nouvelle proposition �.", vbExclamation
        Exit Sub
    End If
    If Application.WorksheetFunction.Count(wt.Range(wt.Cells(T_FIRST, 9), wt.Cells(T_LAST, 9))) > 0 Then
        If MsgBox("Des temps r�els sont d�j� saisis dans l'onglet Tournoi. Les remplacer par la proposition n� " & num & " ?", _
                  vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    End If
    lastR = DerniereLigne(wd, 1)
    trouve = False
    For r = 2 To lastR
        If NumVal(wd.Cells(r, 1).Value, 0) = num Then trouve = True: Exit For
    Next r
    If Not trouve Then
        MsgBox "La proposition n� " & num & " n'existe pas.", vbExclamation
        Exit Sub
    End If
    Application.ScreenUpdating = False
    ViderTournoi
    tr = T_FIRST: s1 = S1_FIRST: s2 = S2_FIRST
    For r = 2 To lastR
        If NumVal(wd.Cells(r, 1).Value, 0) = num And CStr(wd.Cells(r, 3).Value) <> "(membre)" Then
            If tr > T_LAST Then Exit For
            wt.Cells(tr, 1).Value = wd.Cells(r, 2).Value
            wt.Cells(tr, 2).Value = wd.Cells(r, 3).Value
            wt.Cells(tr, 3).Value = wd.Cells(r, 4).Value
            wt.Cells(tr, 4).Value = wd.Cells(r, 5).Value
            If CStr(wd.Cells(r, 6).Value) <> "(personne)" Then wt.Cells(tr, 5).Value = wd.Cells(r, 6).Value
            wt.Cells(tr, 6).Value = wd.Cells(r, 8).Value
            wt.Cells(tr, 7).Value = wd.Cells(r, 9).Value
            tr = tr + 1
            ' synthese groupe x epreuve
            cle = CStr(wd.Cells(r, 2).Value) & "�" & CStr(wd.Cells(r, 3).Value)
            trouve = False
            For i = S1_FIRST To s1 - 1
                If CStr(wt.Cells(i, 13).Value) & "�" & CStr(wt.Cells(i, 14).Value) = cle Then trouve = True: Exit For
            Next i
            If Not trouve And s1 <= S1_LAST Then
                wt.Cells(s1, 13).Value = wd.Cells(r, 2).Value
                wt.Cells(s1, 14).Value = wd.Cells(r, 3).Value
                s1 = s1 + 1
            End If
            trouve = False
            For i = S2_FIRST To s2 - 1
                If CStr(wt.Cells(i, 21).Value) = CStr(wd.Cells(r, 2).Value) Then trouve = True: Exit For
            Next i
            If Not trouve And s2 <= S2_LAST Then
                wt.Cells(s2, 21).Value = wd.Cells(r, 2).Value
                s2 = s2 + 1
            End If
        End If
    Next r
    Nm("T_NumProp").Value = num
    Application.ScreenUpdating = True
    wt.Activate
    wt.Cells(T_FIRST, 8).Select
    MsgBox "Proposition n� " & num & " valid�e. Saisissez les temps r�els dans la colonne jaune de l'onglet Tournoi.", vbInformation
End Sub

Private Sub ViderTournoi()
    Dim wt As Worksheet
    Set wt = Sh("shTournoi", "Tournoi")
    wt.Range(wt.Cells(T_FIRST, 1), wt.Cells(T_LAST, 8)).ClearContents
    wt.Range(wt.Cells(S1_FIRST, 13), wt.Cells(S1_LAST, 14)).ClearContents
    wt.Range(wt.Cells(S2_FIRST, 21), wt.Cells(S2_LAST, 21)).ClearContents
    Nm("T_NumProp").ClearContents
End Sub

'=====================================================================
'  BOUTON : EFFACER LES PROPOSITIONS
'=====================================================================
Public Sub EffacerPropositions()
    If MsgBox("Effacer toutes les propositions non valid�es ? (le tournoi valid� est conserv�)", vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    ViderPropositions
    Nm("A_NumProp").ClearContents
End Sub

Private Sub ViderPropositions()
    Dim wp As Worksheet, wd As Worksheet, lastR As Long
    Set wp = Sh("shPropositions", "Propositions")
    Set wd = Sh("shDonnees", "Donn�es")
    lastR = wp.UsedRange.Row + wp.UsedRange.Rows.Count
    If lastR >= 4 Then wp.Range(wp.Rows(4), wp.Rows(lastR + 1)).Delete
    lastR = wd.UsedRange.Row + wd.UsedRange.Rows.Count
    If lastR >= 2 Then
        wd.Range(wd.Cells(2, 1), wd.Cells(lastR + 1, 10)).ClearContents
        wd.Range(wd.Cells(2, 12), wd.Cells(lastR + 1, 15)).ClearContents
    End If
End Sub

'=====================================================================
'  ARCHIVAGE + NOUVEAU TOURNOI
'=====================================================================
Private Function ArchiverTournoi() As Long
    Dim wt As Worksheet, wa As Worksheet, wh As Worksheet
    Dim r As Long, ar As Long, hr As Long, n As Long, nomT As String, dateT As Variant, v As Variant
    Set wt = Sh("shTournoi", "Tournoi")
    Set wa = Sh("shArchives", "Archives")
    Set wh = Sh("shHistorique", "Historique")
    Application.Calculate
    nomT = TxtVal(Nm("R_NomTournoi").Value)
    If nomT = "" Then nomT = "Tournoi"
    dateT = Nm("R_Date").Value
    If Not IsDate(dateT) Then dateT = Date
    ar = DerniereLigne(wa, 1) + 1
    If ar < 2 Then ar = 2
    hr = DerniereLigne(wh, 3) + 1
    If hr < 2 Then hr = 2
    n = 0
    For r = T_FIRST To T_LAST
        If TxtVal(wt.Cells(r, 1).Value) <> "" Then
            wa.Cells(ar, 1).Value = nomT
            wa.Cells(ar, 2).Value = dateT
            wa.Cells(ar, 3).Value = wt.Cells(r, 1).Value
            wa.Cells(ar, 4).Value = wt.Cells(r, 2).Value
            wa.Cells(ar, 5).Value = wt.Cells(r, 3).Value
            wa.Cells(ar, 6).Value = wt.Cells(r, 4).Value
            wa.Cells(ar, 7).Value = wt.Cells(r, 5).Value
            wa.Cells(ar, 8).Value = wt.Cells(r, 6).Value
            wa.Cells(ar, 9).Value = wt.Cells(r, 7).Value
            v = wt.Cells(r, 9).Value
            If NumVal(v, 0) > 0 And VarType(v) <> vbString Then
                wa.Cells(ar, 10).Value = v
                If TxtVal(wt.Cells(r, 5).Value) <> "" Then
                    wh.Cells(hr, 1).Value = dateT
                    wh.Cells(hr, 1).NumberFormat = "dd/mm/yyyy"
                    wh.Cells(hr, 2).Value = nomT
                    wh.Cells(hr, 3).Value = wt.Cells(r, 5).Value
                    wh.Cells(hr, 4).Value = wt.Cells(r, 4).Value
                    wh.Cells(hr, 5).Value = wt.Cells(r, 6).Value
                    wh.Cells(hr, 6).Value = v
                    If hr > H_PREFILL Then
                        wh.Cells(hr, 7).Formula = "=IF(OR(F" & hr & "="""",E" & hr & "="""",E" & hr & "=0),"""",ROUND(F" & hr & "*R_DistRef/E" & hr & ",2))"
                    End If
                    wh.Cells(hr, 8).Value = "Tournoi"
                    hr = hr + 1
                End If
            End If
            ar = ar + 1
            n = n + 1
        End If
    Next r
    If hr > H_PREFILL Then
        MsgBox "Attention : l'historique d�passe " & H_PREFILL - 1 & " lignes ; les calculs n'utilisent que les " & H_PREFILL - 1 & " premi�res.", vbExclamation
    End If
    ArchiverTournoi = n
End Function

Private Sub DemanderNouveauNom()
    Dim s As String
    s = InputBox("Nom du nouveau tournoi (laisser vide pour garder � " & TxtVal(Nm("R_NomTournoi").Value) & " �) :", "Nouveau tournoi")
    If Trim$(s) <> "" Then Nm("R_NomTournoi").Value = Trim$(s)
    Nm("R_Date").Value = Date
End Sub

Public Sub NouveauTournoi_TempsVides()
    Dim n As Long
    If MsgBox("Nouveau tournoi avec temps � ressaisir :" & vbLf & vbLf & _
              "� le tournoi actuel est archiv� (Archives + Historique)" & vbLf & _
              "� les propositions et le tournoi sont vid�s" & vbLf & _
              "� les temps de l'onglet Participants sont effac�s (noms, sexes, couleurs conserv�s)" & vbLf & vbLf & _
              "Continuer ?", vbYesNo + vbQuestion, "Nouveau tournoi") <> vbYes Then Exit Sub
    Application.ScreenUpdating = False
    n = ArchiverTournoi()
    ViderTournoi
    ViderPropositions
    Sh("shParticipants", "Participants").Range("F" & P_FIRST & ":I" & P_LAST).ClearContents
    Application.ScreenUpdating = True
    DemanderNouveauNom
    Sh("shParticipants", "Participants").Activate
    MsgBox n & " ligne(s) archiv�e(s). Saisissez les nouveaux temps dans Participants, puis � Nouvelle proposition �." & vbLf & _
           "Rappel : si la r�gle � Quels temps utiliser ? � inclut l'historique, les temps archiv�s servent encore quand une case est vide.", vbInformation
End Sub

Public Sub NouveauTournoi_TempsDuTournoi()
    Dim wt As Worksheet, wp As Worksheet, r As Long, pr As Variant, k As Variant, n As Long
    Dim best() As Double, t As Double, d As Double, nMaj As Long, rr As Long, kk As Long
    If MsgBox("Nouveau tournoi � partir des temps de ce tournoi :" & vbLf & vbLf & _
              "� le tournoi actuel est archiv� (Archives + Historique)" & vbLf & _
              "� chaque temps r�el saisi remplace le temps du nageur dans Participants (converti � la distance de r�f�rence ; s'il a nag� plusieurs fois la m�me nage, le meilleur est gard�)" & vbLf & _
              "� une nouvelle proposition est calcul�e" & vbLf & vbLf & _
              "Continuer ?", vbYesNo + vbQuestion, "Nouveau tournoi") <> vbYes Then Exit Sub
    Set wt = Sh("shTournoi", "Tournoi")
    Set wp = Sh("shParticipants", "Participants")
    Application.Calculate
    ChargerRegles
    ReDim best(P_FIRST To P_LAST, 0 To 3)
    For r = T_FIRST To T_LAST
        If TxtVal(wt.Cells(r, 5).Value) <> "" And VarType(wt.Cells(r, 9).Value) <> vbString Then
            t = NumVal(wt.Cells(r, 9).Value, 0)
            d = NumVal(wt.Cells(r, 6).Value, 0)
            If t > 0 And d > 0 Then
                pr = Application.Match(wt.Cells(r, 5).Value, wp.Range("B" & P_FIRST & ":B" & P_LAST), 0)
                k = Application.Match(wt.Cells(r, 4).Value, Nm("L_Nages"), 0)
                If Not IsError(pr) And Not IsError(k) Then
                    t = Round(t * distRef / d, 2)
                    rr = P_FIRST + CLng(pr) - 1
                    kk = CLng(k) - 1
                    If best(rr, kk) = 0 Or t < best(rr, kk) Then best(rr, kk) = t
                End If
            End If
        End If
    Next r
    Application.ScreenUpdating = False
    n = ArchiverTournoi()
    nMaj = 0
    For rr = P_FIRST To P_LAST
        For kk = 0 To 3
            If best(rr, kk) > 0 Then
                wp.Cells(rr, 6 + kk).Value = best(rr, kk)
                nMaj = nMaj + 1
            End If
        Next kk
    Next rr
    ViderTournoi
    ViderPropositions
    Application.ScreenUpdating = True
    DemanderNouveauNom
    MsgBox n & " ligne(s) archiv�e(s), " & nMaj & " temps mis � jour dans Participants. Calcul d'une nouvelle proposition�", vbInformation
    NouvelleProposition
End Sub

'=====================================================================
'  INSTALLATION DES BOUTONS
'=====================================================================
Public Sub InstallerBoutons()
    Dim wa As Worksheet, wp As Worksheet, wt As Worksheet
    Set wa = Sh("shAccueil", "Accueil")
    Set wp = Sh("shPropositions", "Propositions")
    Set wt = Sh("shTournoi", "Tournoi")
    SupprimerBoutons wa: SupprimerBoutons wp: SupprimerBoutons wt
    AjouterBouton wa, "F4", 330, "1. Nouvelle proposition", "NouvelleProposition", RGB(46, 117, 182)
    AjouterBouton wa, "F6", 330, "2. Valider la proposition choisie", "ValiderProposition", RGB(84, 130, 53)
    AjouterBouton wa, "F8", 330, "Nouveau tournoi : temps � ressaisir", "NouveauTournoi_TempsVides", RGB(191, 143, 0)
    AjouterBouton wa, "F10", 330, "Nouveau tournoi : � partir des temps du tournoi", "NouveauTournoi_TempsDuTournoi", RGB(197, 90, 17)
    AjouterBouton wa, "F12", 330, "Effacer les propositions", "EffacerPropositions", RGB(127, 127, 127)
    AjouterBouton wp, "D1", 200, "Nouvelle proposition", "NouvelleProposition", RGB(46, 117, 182)
    AjouterBouton wp, "F1", 230, "Valider (n� choisi dans Accueil)", "ValiderProposition", RGB(84, 130, 53)
    AjouterBouton wt, "M1", 260, "Nouveau tournoi : temps � ressaisir", "NouveauTournoi_TempsVides", RGB(191, 143, 0)
    AjouterBouton wt, "M3", 260, "Nouveau tournoi : temps du tournoi", "NouveauTournoi_TempsDuTournoi", RGB(197, 90, 17)
    Sh("shAccueil", "Accueil").Range("F20").Value = ""
    MsgBox "Boutons install�s. Enregistrez maintenant le classeur au format .xlsm (classeur prenant en charge les macros).", vbInformation
End Sub

Private Sub SupprimerBoutons(ByVal ws As Worksheet)
    Dim i As Long
    For i = ws.Shapes.Count To 1 Step -1
        If Left$(ws.Shapes(i).Name, 4) = "btn_" Then ws.Shapes(i).Delete
    Next i
End Sub

Private Sub AjouterBouton(ByVal ws As Worksheet, ByVal adr As String, ByVal largeur As Double, ByVal texte As String, _
                          ByVal macro As String, ByVal couleur As Long)
    Dim shp As Shape, c As Range
    Set c = ws.Range(adr)
    Set shp = ws.Shapes.AddShape(5, c.Left + 2, c.Top + 2, largeur, 30)
    shp.Name = "btn_" & macro & "_" & adr
    shp.OnAction = macro
    shp.Fill.ForeColor.RGB = couleur
    shp.Line.Visible = msoFalse
    shp.Placement = xlFreeFloating
    With shp.TextFrame2
        .VerticalAnchor = msoAnchorMiddle
        With .TextRange
            .Text = texte
            .Font.Size = 11
            .Font.Bold = msoTrue
            .Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
            .ParagraphFormat.Alignment = msoAlignCenter
        End With
    End With
End Sub
